

# Proyectos de Storytelling 2021

Digital Storytelling / Narraciones y creatividad en ecosistema digital 2020-21

Página con proyectos publicados en la Web http://utopolis.ugr.es/media/HRUN/ 

## Historias H - Hackeando el sistema 

Proyectos realizados: 

- 


## Historia R - Robot & IA 

- 

## Historia U - mUltiversos: universos distópicos

- 

## Historia N - Nómadas  

- 


-----



![](https://upload.wikimedia.org/wikipedia/commons/thumb/6/62/CC-BY-SA-Andere_Wikis_%28v%29.svg/200px-CC-BY-SA-Andere_Wikis_%28v%29.svg.png)

Mayo 2021 

[Creacion y Difusión de Nuevos Contenidos Audiovisuales](http://utopolis.ugr.es/medialab)

[Facultad de Comunicación y Documentación](http://fcd.ugr.es)

Universidad de Granada
