

# Proyectos de Storytelling 2020

Digital Storytelling / Narraciones y creatividad en ecosistema digital 2019-20

Página con proyectos publicados en la Web http://utopolis.ugr.es/media/HRUN/ 

## Historias H - Hackeando el sistema 

Proyectos realizados: 

- [Joseba]() Robot obsoleto que vive en Marte (adaptandose al entorno) 
- [Miquel]() Adolescente solitario programador que crea videojuego con problema en instituto  
- [Porfiplis]() Hacker famoso que no soporta a Kim Jong-un y planea ataques 


## Historia R - Robot & IA 

- [Rob-i](https://github.com/emememe/storytelling_20/blob/master/proyecto.md) Robots y humanos conviven , pero los robots no quieren  ser programados para ser libres [Storytelling/Visual Novel](http://utopolis.ugr.es/media/HRUN/R/R1-2020_Robi)
- [Eri]() Niña en mundo dominado por robots e intenta escapar
- [Miausolini]() Gato de la calle con chip  que se rebela


## Historia U - mUltiversos: universos distópicos

- 

## Historia N - Nómadas  

- [Nachovio]() Camarero desequilibrado [Storytelling/Visual Novel](https://view.genial.ly/5e9d769360a2da0dc806fa42/interactive-content-nachovio) 
- [Marselo]() Musico fracasado que viaja al pasado para cambiar la historia 
- [Lisandra]() Maniatica teleoperadora que quiere cambiar su vida [Storytelling/Visual Novel](https://view.genial.ly/5e9840a0d1e1fc0dea3625d6/presentation-lisandra)
- [CarlosSanfrancisco]() Funcionario verbenero con doble vida y le gusta la canción popular 



## 2B Banners

![Banners](https://github.com/mgea/storytelling_20/blob/master/2020/banner_2020.png)
http://utopolis.ugr.es/media/storytelling/2020/banners/


## 3B Novelas Visuales 

H1 [Historia de El Banano](http://utopolis.ugr.es/media/HRUN/H/H1-2020_El_Banano) 

H2 [Miquell y los comics](http://utopolis.ugr.es/media/HRUN/H/H2-2020_Miquell)

H3 [Future of Emo](http://utopolis.ugr.es/media/HRUN/H/H3-2020_FutureEmo)

R1 [Rob-i robot que quiere ser libre](http://utopolis.ugr.es/media/HRUN/R/R1-2020_Robi)

R2 [Eri, escapa del mundo de robots](http://utopolis.ugr.es/media/HRUN/R/R2-2020_Eribot)

R3 [Miausolini](http://utopolis.ugr.es/media/HRUN/R/R3-2020_Call_of_Kitten)

R4 [Josebot](http://utopolis.ugr.es/media/HRUN/R/R4-2020_Josebot) 

N1 [Nachovio, el Camarero desequilibrado](https://view.genial.ly/5e9d769360a2da0dc806fa42/interactive-content-nachovio)

N2 [Lisandra, la Maniatica teleoperadora](https://view.genial.ly/5e9840a0d1e1fc0dea3625d6/presentation-lisandra) 

N3 [Pokemon Orgullo Nazarí](http://utopolis.ugr.es/media/HRUN/N/N3-2020_PokemonOrgulloNazari)




-----



![](https://upload.wikimedia.org/wikipedia/commons/thumb/6/62/CC-BY-SA-Andere_Wikis_%28v%29.svg/200px-CC-BY-SA-Andere_Wikis_%28v%29.svg.png)

Mayo 2020 

[Creacion y Difusión de Nuevos Contenidos Audiovisuales](http://utopolis.ugr.es/medialab)

[Facultad de Comunicación y Documentación](http://fcd.ugr.es)

Universidad de Granada
