# Proyecto H1_SOLO

![](https://pbs.twimg.com/profile_images/705223576945700864/FuC-WWlc_400x400.jpg)
![](http://www.fd4a.net/Android_Icons/3D-Matrix-Pro-Vol-3-Revolution.png)
![](https://pbs.twimg.com/profile_images/588150066529046528/j93MmaCF_400x400.jpg)
![](http://multimedialasflores.com.ar/wp-content/uploads/2018/10/001-cohete.png)
--

Nombre del Equipo: :blue_heart:   :blue_heart:

Proyecto 

Resumen:  


- Contexto: 

- Personaje: 

- Historia: 

- Conflicto: 




- ChatBot:  

- Banner:  

- Storytelling: 

------
![](https://upload.wikimedia.org/wikipedia/commons/thumb/6/62/CC-BY-SA-Andere_Wikis_%28v%29.svg/200px-CC-BY-SA-Andere_Wikis_%28v%29.svg.png)


Autores: 
- :man: 
- :woman:
- :woman: 

<!---
Lista completa de emojis de markDown - https://gist.github.com/rxaviers/7360908) 
-->



Febrero, 2019

[Creacion y Difusión de Nuevos Contenidos Audiovisuales](http://utopolis.ugr.es/medialab)

[Facultad de Comunicación y Documentación](http://fcd.ugr.es)

Universidad de Granada
