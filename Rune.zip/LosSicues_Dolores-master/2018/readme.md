# Proyectos de Storytelling 

Digital Storytelling / Narraciones y creatividad en ecosistema digital 2017-18

Página con proyectos publicados en la Web http://utopolis.ugr.es/media/HRUN/ 

## Historias H - Hackeando el sistema 

Proyectos realizados: 

- [Los juegos de la Conspiración](https://github.com/Yogutijara/storytelling/blob/master/L2H-Zoe.md) 
- [Imabot] 
- [CK Project](https://github.com/mariina611/storytelling/blob/master/)


## Historia R - Robot & IA 

- [ROOT](https://github.com/mjcub/storytelling/blob/master/L2R-root.md)
- [TheMadLine](https://github.com/MayLuzon/storytelling/blob/master/L2R-TheMadline.md)
- [Rosseliano](https://github.com/pcabrerizo/storytelling/blob/master/L2N-Rosseliano.md)


## Historia U - mUltiversos: universos paralelos

- [Martin MacFlurry](https://github.com/aicitel10/storytelling/blob/master/L2U-M.Macflurry.md)
- [Andrea005D](https://github.com/Corif/storytelling/blob/master/L2U-meriendacena)

## Historia N - Neolenguas 

- [Paquito el aurtista] 


![](https://upload.wikimedia.org/wikipedia/commons/thumb/6/62/CC-BY-SA-Andere_Wikis_%28v%29.svg/200px-CC-BY-SA-Andere_Wikis_%28v%29.svg.png)

Junio 2018 

[Creacion y Difusión de Nuevos Contenidos Audiovisuales](http://utopolis.ugr.es/medialab)

[Facultad de Comunicación y Documentación](http://fcd.ugr.es)

Universidad de Granada
